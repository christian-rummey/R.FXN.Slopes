# require -----------------------------------------------------------------
# fxn.1 is the less organized sheet (althhough it may have more data)
# fxn.1 <- read_excel("DATA/Master FXN Sample Data DL112918(1).xlsx", sheet = "FXN Blood Data 2018", na=c("?","X")) %>% 
#   rename(
#     sjid    = 'FACOMS',
#     cdt     = "Date of Collection"
#   ) %>% 
#   mutate(cdt = as.Date(as.numeric(cdt), origin = as.Date('1899-12-30'))) %>% 
#   select(sjid, cdt, "Loaded", "FXN mABS", "GAM mABS", "FXN Corrected", "% of Average ctl", "Average...10")
# require 2 ---------------------------------------------------------------
# Only looking at patients from FA-COMS - to compare clinical data. 
# using Average of % of average control (for plate differences) 
# I am using only frataxin columns, although there are more patients with data in here. 

rm(list=ls())

types <- c('text','text','date','text','text','text','text','text','text','text',
           'text','text','text','text','text','text','text','text','text','text',
           'text','text','text','text','text','text','text')

fxn.bucc   <- readxl::read_excel("DATA/Master FXN Sample Data DL112918(1).xlsx", sheet = "FXN BC Data 2018", na=c("?","X"), #) %>% 
                                 col_types = types) %>% 
  select(
    sjid    = 'FACOMS ID',
    # cdt     = "Date of Collection",
    status  = 'Status',
    # pct.ctr = `% of Average Ctl`,
    fxn.pct = Average,
    n       = N
    )

# fxn.bucc %>% 
#   mutate_at(vars('pct.ctr','fxn.pct','n'), as.numeric) %>%
#   group_by(sjid) %>% 
#   summarise(
#     pct.ctr = mean(pct.ctr, na.rm=T),
#     n.pct.ctr = n(),
#     fxn.pct = mean(fxn.pct, na.rm=T),
#   ) %>%
#   ggplot()+geom_point()+
#   aes(x = pct.ctr, y = fxn.pct)

# sometimes the average was done several times. 
fxn.bucc %<>% 
  filter(fxn.pct>0) %>% 
  filter(!is.na(fxn.pct)) %>% 
  group_by(sjid, fxn.pct) %>% 
  filter(rank(fxn.pct, ties.method = 'first')==1)

fxn.bucc %<>% 
  mutate_at(vars('fxn.pct','n'), as.numeric) %>% 
  mutate(n        = as.numeric(n))

fxn.blood   <- readxl::read_excel("DATA/Master FXN Sample Data DL112918(1).xlsx", sheet = "FXN Blood Data 2018") %>% 
  select(
    sjid    = 'FACOMS',
    # cdt     = `Date of Collection`,
    status  = 'Status',
    # fxn.pct = `% of Average ctl`,
    fxn.pct = Average...10,
    n       = `N...11`
  ) %>% 
  filter(!is.na(fxn.pct))

# same as above
fxn.blood %<>% 
  filter(fxn.pct>0) %>% 
  filter(!is.na(fxn.pct)) %>% 
  group_by(sjid, fxn.pct) %>% 
  filter(rank(fxn.pct, ties.method = 'first')==1)

fxn.coms <- bind_rows(
  fxn.bucc  %>% mutate(origin = 'buccal') %>% mutate(sjid = as.character(sjid)), 
  fxn.blood %>% mutate(origin = 'blood')
) 

rm(fxn.bucc, fxn.blood, types)

fxn.coms %<>%
  ungroup %>% 
  mutate(sjid = ifelse(sjid == 'No ID', paste('No ID',row_number()), sjid))

fxn.coms %<>% 
  mutate(study = 'FACOMS') %>% 
  left_join(.dd('demo') ) %>% 
  mutate ( fxn.unit = '%' ) %>%
  rename ( fxn      = fxn.pct ) %>% 
  mutate ( fxn      = log10(fxn)) %>%
  # select ( -fxn.mean ) %>% 
  select ( study, origin, site, sjid, status, fxn.unit, everything())

fxn.coms %<>% 
  mutate(status = ifelse(is.na(site) & status == 'Patient', 'Patient.ext', status)) %>% 
  mutate(status = ifelse(status == 'control','Control', status))

fxn.coms %<>% 
  group_by(origin, status, sjid) %>%
  mutate(fxn = mean(fxn), n = sum(n)) %>%
  # filter(n()>1)
  unique()

fxn.coms %>% 
  group_by(origin, status) %>%
  summarise( n = n(), s = length(unique(sjid)))

# AVERAGING of values needs to happen before LOG!! ------------------------
# 
# fxn.bucc %>% 
#   mutate(Status = ifelse(Status == 'control','Control', Status)) %>% 
#   # filter((sjid %in% demo.$sjid) | (Status != 'Patient')) %>% 
#   select(Status, sjid, cdt, "ug/ul", "FXN mABS", "GAM mABS", "FXN Corrected", "% of Average Ctl", "Average") %>%
#   rename(ug.lu    = `ug/ul`,
#          fxn.abs  = `FXN mABS`, 
#          gam.abs  = `GAM mABS`,
#          fxn.corr = `FXN Corrected`,
#          fxn.actl = `% of Average Ctl`) %>% 
#   # rename(fxn = fxn.corr) %>% # NOV 2023
#   rename(fxn = fxn.actl) %>% 
#   select(-Average) %>% 
#   mutate(cdt = as.Date(cdt)) %>% 
#   mutate_at(c('fxn'), as.numeric) %>% 
#   filter(!is.na(fxn)) %>% 
#   # mutate(fxn.l = log10(fxn)) %>% 
#   # filter(is.na(fxn.l))
#   select(Status, sjid, cdt, fxn)
# 
# filter(fxn.bucc, is.na(fxn))
# 
# fxn.bucc %<>% 
#   # filter(sjid == 20) %>%
#   # filter(is.na(cdt))
#   # filter(sjid == 6007) %>% 
#   group_by(Status, sjid) %>%
#   # mutate ( earliest = min(cdt, na.rm=T), latest = max(cdt, na.rm=T)) %>% 
#   # mutate ( d.range = as.numeric( latest - earliest )) %>% 
#   # group_by( Status, sjid, earliest, d.range ) %>%
#   group_by( sjid, Status ) %>%
#   select(-cdt) %>% 
#   summarise(
#     # n     = n(),
#     fxn   = mean(fxn  , na.rm=T),
#   ) %>% 
#   mutate(fxn.l = log10(fxn))
# 
# fxn.bucc %<>% filter(n()==1)

# %>% 
#   mutate(age = as.numeric(earliest-birthdt)/365.25)


