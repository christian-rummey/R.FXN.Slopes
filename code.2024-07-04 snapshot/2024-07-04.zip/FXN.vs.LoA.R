# intro -------------------------------------------------------------------

rm(list=ls())

source('DM.FXN.FACOMS.R')
source('DM.FXN.FACHILD.R')

fxn. <- bind_rows(
  fxn.coms,
  fxn.child
) %>% 
  mutate( status = tolower(status)) %>% 
  mutate( status = factor (status, c('patient', 'patient.ext', 'carrier','control','unknown'))) 
# filter( status == 'patient', is.na(gaa1))
# mutate( mutation = pm )

# symp on x ---------------------------------------------------------------

fxn.tmp <- fxn. %>% 
  mutate(group = paste( study, origin, type )) %>% 
  # filter( (status %in% c('Patient','homozygous','point mut.'))) %>%
  # filter( (origin %in% c('buccal','blood'))) %>% 
  # filter(study == 'FACOMS') %>% 
  droplevels()

# 339 LoAs ----------------------------------------------------------------

LoA <- .dd('steps') %>%
  filter(study == 'FACOMS') %>%
  group_by(sjid) %>%
  filter  ( length(unique(amb))>1 ) %>%
  filter  ( amb == 'ambulatory') %>% filter(avisitn==max(avisitn)) %>%
  .add.time(tm='age') %>%
  mutate  ( LoA.age = age) %>% ungroup %>%
  select(sjid, LoA.age)

# last visit of all of them. ----------------------------------------------

LoA.all <- .dd('steps') %>% 
  filter(study == 'FACOMS') %>% 
  group_by(sjid) %>% 
  # filter  ( length(unique(amb))>1 ) %>% 
  filter  ( amb == 'ambulatory') %>% filter(avisitn==max(avisitn)) %>% 
  .add.time(tm='age') %>% 
  left_join(LoA) %>% 
  mutate  ( last.age = age) %>% ungroup %>% 
  select(sjid, LoA.age, last.age)

LoA.all %<>% 
  mutate(event = ifelse(is.na(LoA.age), 0, 1))

# fxn.tmp %<>% 
#   filter(aoo<25) %>% 
#   left_join(LoA)

# add LoA dates to fxn file--------------------------------------------------

fxn.tmp %<>%
  left_join(LoA)

# LoA Age vs fxn, all 4  --------------------------------------------------

fxn.tmp %>%
  filter(!is.na(LoA.age)) %>%
  group_by(sjid) %>% 
  ggplot()+geom_point()+
  aes(fxn, LoA.age )+
  # aes(value, LoA.age)+
  ggpubr::stat_cor( data = filter(fxn.tmp, status %in% c('Patient','homozygous')), output.type	= 'tex',show.legend = F)+
  geom_smooth     ( data = filter(fxn.tmp, status %in% c('Patient','homozygous')), method = 'lm', se = F, aes(group= 1))+
  facet_wrap(~group, ncol = 2)+
  theme_minimal(base_size = 16)+
  ggpmisc::stat_correlation(mapping = ggpmisc::use_label(c("R2", "P", "n")))+
  geom_smooth     (  method = 'lm', se = F, aes(group= 1))+
  # .leg_lrh+
  # ylim(0,1350)+
  # xlim(0,25)+
  # ylab('gaa1 (repeat length shorter allele)')+
  # xlab('FXN.l')+
  .box

# boxplot LoA by FXN Percentiles ------------------------------------------

fxn.tmp %>%
  filter(!is.na(LoA.age)) %>%
  # filter(LoA.age>40, study == 'FACHILD') %>%
  group_by(group) %>% filter(!is.na(fxn)) %>%
  mutate( fxn.cat = ntile(fxn,4)) %>% 
  # filter(is.na(fxn.cat))
  ggplot()+geom_boxplot()+
  aes(y = LoA.age, x = factor(fxn.cat) )+
  # aes(fill = fxn.cat)+
  # aes(value, LoA.age)+
  facet_wrap(~ group, ncol = 2)+
  theme_minimal(base_size = 16)+
  .leg_none+
  .box+
  xlab('FXN percentiles')+
  ylab('Age at LoA')
# hist(fxn.tmp$LoA.age)

# cox model? --------------------------------------------------------------

fxn.tmp$group %>% table

tte <- fxn.tmp %>%
  mutate(gaa1 = gaa1/100) %>% 
  filter(group %in% c('FACHILD blood isoform.e','FACOMS blood NA') )  %>%
  left_join(
    LoA.all
  ) %>% 
  # filter(event == 0) %>% 
  filter(!is.na(event)) %>% # all others were enrolled non-amb.
  select( group, sjid, aoo, gaa1, fxn, time = LoA.age, event )

fit <- survfit(Surv(tte$time, tte$event)~group, data = tte)

fit %>% 
  ggsurvplot(data = tte, pval = T, censor = T)

table(tte$group)

tte.H <- filter(tte, group != 'FACOMS blood NA') 
tte.O <- filter(tte, group == 'FACOMS blood NA') 

results <- bind_rows(
  coxph(Surv(tte.H$time, tte.H$event)~ aoo  , data = tte.H ) %>% broom::tidy(exp = T, conf.int = T),
  coxph(Surv(tte.H$time, tte.H$event)~ gaa1 , data = tte.H ) %>% broom::tidy(exp = T, conf.int = T),
  coxph(Surv(tte.H$time, tte.H$event)~ fxn  , data = tte.H ) %>% broom::tidy(exp = T, conf.int = T),
  # coxph(Surv(tte.H$time, tte.H$event)~ aoo  + gaa1, data = tte.H ) %>% broom::tidy(exp = T, conf.int = T),
  # coxph(Surv(tte.H$time, tte.H$event)~ aoo  + fxn , data = tte.H ) %>% broom::tidy(exp = T, conf.int = T),
  # coxph(Surv(tte.H$time, tte.H$event)~ fxn  + gaa1, data = tte.H ) %>% broom::tidy(exp = T, conf.int = T),
  # coxph(Surv(tte.H$time, tte.H$event)~ fxn  + gaa1 + aoo , data = tte.H ) %>% broom::tidy(exp = T, conf.int = T),
  coxph(Surv(tte.O$time, tte.O$event)~ aoo  , data = tte.O ) %>% broom::tidy(exp = T, conf.int = T),
  coxph(Surv(tte.O$time, tte.O$event)~ gaa1 , data = tte.O ) %>% broom::tidy(exp = T, conf.int = T),
  coxph(Surv(tte.O$time, tte.O$event)~ fxn  , data = tte.O ) %>% broom::tidy(exp = T, conf.int = T),
  # coxph(Surv(tte.O$time, tte.O$event)~ aoo  + gaa1, data = tte.O ) %>% broom::tidy(exp = T, conf.int = T),
  # coxph(Surv(tte.O$time, tte.O$event)~ aoo  + fxn , data = tte.O ) %>% broom::tidy(exp = T, conf.int = T),
  # coxph(Surv(tte.O$time, tte.O$event)~ fxn  + gaa1, data = tte.O ) %>% broom::tidy(exp = T, conf.int = T),
  # coxph(Surv(tte.O$time, tte.O$event)~ fxn  + gaa1 + aoo , data = tte.O ) %>% broom::tidy(exp = T, conf.int = T)
)
results %>% .ct


bind_rows(
  coxph(Surv(tte$time, tte$event)~ aoo, data = tte ) %>% broom::tidy(exp = T, conf.int = T),
  coxph(Surv(tte$time, tte$event)~ gaa1, data = tte ) %>% broom::tidy(exp = F, conf.int = T),
  coxph(Surv(tte$time, tte$event)~ fxn, data = tte ) %>% broom::tidy(exp = T, conf.int = T)
) %>% .fixmod()

.Last.value %>% .ct




# correct COX model with censoring ----------------------------------------
# cox model? --------------------------------------------------------------

amb.sjids <- filter(LoA.all, event == 0) %>% select(sjid) %>% deframe

sjids.amb.last.ages <- .dd('steps') %>% 
  filter(sjid %in% amb.sjids) %>% 
  group_by(sjid) %>% 
  filter(avisitn == max(avisitn)) %>% 
  # ungroup() %>% select(fds.act) %>% table %>% 
  .add.time(tm = 'age') %>% 
  select(sjid, age)

fxn.tmp$group %>% table

tte <- fxn.tmp %>%
  mutate(gaa1 = gaa1/100) %>% 
  filter(group %in% c('FACHILD blood isoform.e','FACOMS blood NA') )  %>%
  left_join(
    LoA.all
  ) %>% 
  # filter(event == 0) %>% 
  filter(!is.na(event)) %>% # all others were enrolled non-amb.
  select( group, sjid, aoo, gaa1, fxn, time = LoA.age, event )

tte %<>% 
  left_join(sjids.amb.last.ages) %>%
  mutate(time = ifelse(is.na(time), age, time)) %>%
  select(-amb, -age)

fit <- survfit(Surv(tte$time, tte$event)~group, data = tte)
fit

fit %>% 
  ggsurvplot(data = tte, pval = T, censor = T)

table(tte$group)

tte.H <- filter(tte, group != 'FACOMS blood NA') 
tte.O <- filter(tte, group == 'FACOMS blood NA') 

results <- bind_rows(
  coxph(Surv(tte.H$time, tte.H$event)~ aoo  , data = tte.H ) %>% broom::tidy(exp = T, conf.int = T),
  coxph(Surv(tte.H$time, tte.H$event)~ gaa1 , data = tte.H ) %>% broom::tidy(exp = T, conf.int = T),
  coxph(Surv(tte.H$time, tte.H$event)~ fxn  , data = tte.H ) %>% broom::tidy(exp = T, conf.int = T),
  # coxph(Surv(tte.H$time, tte.H$event)~ aoo  + gaa1, data = tte.H ) %>% broom::tidy(exp = T, conf.int = T),
  # coxph(Surv(tte.H$time, tte.H$event)~ aoo  + fxn , data = tte.H ) %>% broom::tidy(exp = T, conf.int = T),
  # coxph(Surv(tte.H$time, tte.H$event)~ fxn  + gaa1, data = tte.H ) %>% broom::tidy(exp = T, conf.int = T),
  # coxph(Surv(tte.H$time, tte.H$event)~ fxn  + gaa1 + aoo , data = tte.H ) %>% broom::tidy(exp = T, conf.int = T),
  coxph(Surv(tte.O$time, tte.O$event)~ aoo  , data = tte.O ) %>% broom::tidy(exp = T, conf.int = T),
  coxph(Surv(tte.O$time, tte.O$event)~ gaa1 , data = tte.O ) %>% broom::tidy(exp = T, conf.int = T),
  coxph(Surv(tte.O$time, tte.O$event)~ fxn  , data = tte.O ) %>% broom::tidy(exp = T, conf.int = T),
  # coxph(Surv(tte.O$time, tte.O$event)~ aoo  + gaa1, data = tte.O ) %>% broom::tidy(exp = T, conf.int = T),
  # coxph(Surv(tte.O$time, tte.O$event)~ aoo  + fxn , data = tte.O ) %>% broom::tidy(exp = T, conf.int = T),
  # coxph(Surv(tte.O$time, tte.O$event)~ fxn  + gaa1, data = tte.O ) %>% broom::tidy(exp = T, conf.int = T),
  # coxph(Surv(tte.O$time, tte.O$event)~ fxn  + gaa1 + aoo , data = tte.O ) %>% broom::tidy(exp = T, conf.int = T)
)
results %>% .ct


bind_rows(
  coxph(Surv(tte$time, tte$event)~ aoo, data = tte ) %>% broom::tidy(exp = T, conf.int = T),
  coxph(Surv(tte$time, tte$event)~ gaa1, data = tte ) %>% broom::tidy(exp = F, conf.int = T),
  coxph(Surv(tte$time, tte$event)~ fxn, data = tte ) %>% broom::tidy(exp = T, conf.int = T)
) %>% .fixmod()

.Last.value %>% .ct














