
rm(list=ls())

# source('DM.FXN.FACOMS.R')
# source('DM.FXN.FACHILD.R')

source('FXN Slope models DM.R')

# fxn. <- bind_rows(
#   fxn.coms,
#   fxn.child
# ) %>% 
#   mutate( status = tolower(status)) %>% 
#   mutate( status = factor (status, c('patient', 'patient.ext', 'carrier','control','unknown'))) 
# # filter( status == 'patient', is.na(gaa1))
# # mutate( mutation = pm )


with(fxn., table(group, status) )
with(fxn., table(group , status) )
with(fxn., table(type , pm) )

fxn. %>% 
  # filter(grepl('FACHILD', group)) %>%
  group_by(group, status) %>% 
  filter(status!='unknown') %>% 
  filter(status!='patient.ext') %>% 
  summarise(
    geometric_mean.e  = exp(mean(fxn)),
    geometric_mean.10 = 10^(mean(fxn))
    ) %>% 
  mutate(pct = round( (100*geometric_mean.e/max(geometric_mean.e)), 0))

# boxplot FACHILD  ---------------------------------------------------------

fxn. %>% 
  filter(grepl('FACHILD', group)) %>%
  group_by(group, status) %>% 
  summarise(10^mean(fxn))


fxn. %>% 
  filter(grepl('FACHILD', group)) %>%
  # filter(status != 'Unknown') %>% 
  # filter(type %in% c('fxn.l', 'isoform.e.l')) %>% 
  ggplot()+geom_boxplot()+
  aes(x = status)+
  aes(y = fxn)+
  # aes(color = pm)+
  facet_wrap(~group, ncol= 4)+
  ylab('FXN, log10, [ng/ml]')

# .sp()

fxn. %>% 
  filter(study == 'FACHILD') %>% 
  # filter(status != 'Unknown') %>% 
  # filter(type %in% c('fxn.l', 'isoform.e.l')) %>% 
  group_by(study, origin, type, status) %>% 
  mutate(fxn = 10^fxn) %>% 
  summarise(median = median(fxn)) %>% 
  mutate(control = mean( ifelse(status == 'control', median, NA)  , na.rm=T)) %>%
  mutate(pct = 100*median/control) %>% 
  flextable() %>% 
  colformat_double() %>%
  .st()


# boxplot FACHILD  ---------------------------------------------------------

fxn. %>% 
  filter(study != 'FACHILD') %>% 
  # filter(status != 'Unknown') %>% 
  # filter(type %in% c('fxn.l', 'isoform.e.l')) %>% 
  ggplot()+geom_boxplot()+
  aes(x = status)+
  aes(y = fxn)+
  # aes(color = pm)+
  facet_wrap(~paste(study, origin ), ncol= 4)+
  ylab('FXN, log10, [% of normal]')

fxn. %>% 
  filter(study != 'FACHILD') %>% 
  # filter(status != 'Unknown') %>% 
  # filter(type %in% c('fxn.l', 'isoform.e.l')) %>% 
  group_by(study, origin, type, status) %>% 
  mutate(fxn = 10^fxn) %>% 
  summarise(median = median(fxn)) %>% 
  mutate(control = mean( ifelse(status == 'control', median, NA)  , na.rm=T)) %>%
  mutate(pct = 100*median/control) %>% 
  flextable() %>% 
  colformat_double() %>%
  .st()


# fxn. %>% 
#   filter(study != 'FACHILD') %>% 
#   # filter(status != 'Unknown') %>% 
#   # filter(type %in% c('fxn.l', 'isoform.e.l')) %>% 
#   ggplot()+geom_boxplot()+
#   aes(x = status)+
#   aes(y = log10(fxn)   )+
#   # aes(color = pm)+
#   facet_wrap(~paste(study, origin ), scales ='free', ncol= 4)+
#   ylab('FXN, log10, [% of normal]')

# .sp()

# histogram ---------------------------------------------------------------

# fxn.tmp <- fxn %>% 
#   filter( (status %in% c('Patient','homozygous','point mut.'))) %>%
#   filter( (type %in% c('isoform.e.l','fxn.l')))

fxn. %>%
  ggplot()+geom_histogram(position = 'identity', alpha = 0.5)+
  aes(x = 10^fxn)+
  aes(fill = status)+
  facet_wrap(paste(study, type)~origin, scales = 'free_y')

fxn.fachild %>%
  mutate(gaa1 = ifelse(is.na(gaa1), gaa2, gaa1)) %>% 
  filter(!is.na(gaa1)) %>% 
  mutate(gaa.cat = cut(gaa1, c(0, 600, 750, 1500))) %>% 
  mutate(
    mature.l = log10(mature), 
    isoform.e.l = log(isoform.e),
    total.l = log(total),
    ) %>% 
  mutate(mature.l = log10(mature), isoform.e.l = log(isoform.e)) %>% 
  rename(aoo = symp) %>% 
  # mutate(aoo = log(aoo)) %>% 
  gather(type, value, aoo, gaa1, mature, mature.l, isoform.e, isoform.e.l, total, total.l) %>% 
  ggplot()+
  geom_histogram(position = 'identity', alpha = 0.5)+
  # geom_density(position = 'identity', alpha = 0.5)+
  aes(x = value)+
  # aes(fill = gaa.cat)+
  facet_wrap(~type, scales = 'free', ncol = 2)


# .sp()

# fxn.blood %>% 
#   gather(type, value, aoo, gaa1, fxn, fxn.l) %>% 
#   ggplot()+geom_histogram()+
#   aes(x = value)+
#   aes(fill = Status)+
#   facet_wrap(~type, scales = 'free_x')


# . -----------------------------------------------------------------------

fxn %>% 
  filter(status != 'Unknown') %>% 
  filter(type %in% c('fxn.l', 'mature.l', 'isoform.e.l')) %>% 
  ggplot()+geom_boxplot()+
  aes(x = status)+
  aes(y = value)+
  facet_wrap(~paste(study, type), scales ='free')


  
  
  
