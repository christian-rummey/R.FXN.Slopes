
# since average avals are similar over the groups, I can argue that pm is not necessary as 
# fixed factor. If used as such, it drains effects from interaction term.  
# including time. or not changes the way results are presented (p.value for change or p-value for interaction)
# adjusting by gaa makes the estimates slightly more realistic (although p.value is not significant)

# preview model ------------------------------------------------------------

table(fxn.$group)

fxn.dt. <- fxn. %>% 
  left_join(dt.) %>% filter(!is.na(paramcd)) %>% 
  unnest(data) %>% group_by(sjid)

fxn.dt. %>% 
  filter( group == 'FACOMS blood mature' ) %>%
  # filter(n()>1) %>% 
  filter(pm==0) %>%
  lmer(aval ~ bl +  fxn + time. + (1 + time.|sjid) , data = . , control = .lme4.ctrl ) %>%
  # lmer(aval ~ bl +       fxn:time. + time. + (1 + time.|sjid) , data = . , control = .lme4.ctrl ) %>% 
  # lmer(aval ~ bl + fxn + fxn:time. + time. + (1 + time.|sjid) , data = . , control = .lme4.ctrl ) %>% 
  broom::tidy(effects = "fixed", conf.int = T) %>% 
  .fixmod()

# nested models -----------------------------------------------------------

fxn.nest.groups <- fxn.dt. %>% 
  filter(pm==0) %>%
  group_by( group, paramcd ) %>% nest()

models <- bind_rows(
  fxn.nest.groups %>% mutate(m='FF')%>% mutate( mod.fxn = map( data, ~ lmer(aval ~ bl + fxn + time. + (1 + time.|sjid) , data = . , control = .lme4.ctrl ))),
  fxn.nest.groups %>% mutate(m='FF')%>% mutate( mod.fxn = map( data, ~ lmer(aval ~ bl + aoo + time. + (1 + time.|sjid) , data = . , control = .lme4.ctrl ))),
  fxn.nest.groups %>% mutate(m='FF')%>% mutate( mod.fxn = map( data, ~ lmer(aval ~ bl + gaa100 + time. + (1 + time.|sjid) , data = . , control = .lme4.ctrl ))),
  fxn.nest.groups %>% mutate(m='3FF')%>% mutate( mod.fxn = map( data, ~ lmer(aval ~ bl + fxn + aoo + gaa100 + time. + (1 + time.|sjid) , data = . , control = .lme4.ctrl ))),
  # fxn.nest %>% mutate(m='T+I')%>% mutate( mod.fxn = map( data, ~ lmer(aval ~ bl + fxn*time.+ (1 + time.|sjid) , data = . , control = .lme4.ctrl ))),
  # fxn.nest %>% mutate(m='Io') %>% mutate( mod.fxn = map( data, ~ lmer(aval ~ bl + fxn:time.+ (1 + time.|sjid) , data = . , control = .lme4.ctrl ))),
  # # fxn.nest %>% mutate(m='T+I')%>% mutate( mod.fxn = map( data, ~ lmer(aval ~ bl + aoo:time.    + time.   + (1 + time.|sjid) , data = . , control = .lme4.ctrl ))),
  # # fxn.nest %>% mutate(m='Io') %>% mutate( mod.fxn = map( data, ~ lmer(aval ~ bl + aoo:time.    + (1 + time.|sjid) , data = . , control = .lme4.ctrl ))),
  # fxn.nest %>% mutate(m='T+I')%>% mutate( mod.fxn = map( data, ~ lmer(aval ~ bl + gaa100:time. + time.   + (1 + time.|sjid) , data = . , control = .lme4.ctrl ))),
  # fxn.nest %>% mutate(m='Io') %>% mutate( mod.fxn = map( data, ~ lmer(aval ~ bl + gaa100:time. + (1 + time.|sjid) , data = . , control = .lme4.ctrl ))),
  # fxn.nest %>% mutate(m='triple, no I') %>% mutate( mod.fxn = map( data, ~ lmer(aval ~ bl + fxn + aoo + gaa100 + time. + (1 + time.|sjid) , data = . , control = .lme4.ctrl )))
  # fxn. %>% group_by( group, paramcd ) %>% nest() %>% mutate(model = 'all factors') %>%  
  #   mutate( mod.fxn = map( data, ~ lmer(aval ~ bl + fxn + fxn:time.    + (1 + time.|sjid) , data = . , control = .lme4.ctrl ))),
  # fxn. %>% group_by( group, paramcd ) %>% nest() %>% mutate(model = 'all factors') %>% 
  #   mutate( mod.fxn = map( data, ~ lmer(aval ~ bl + aoo+ aoo:time.    + (1 + time.|sjid) , data = . , control = .lme4.ctrl ))),
  # fxn. %>% group_by( group, paramcd ) %>% nest() %>% mutate(model = 'all factors') %>% 
  #   mutate( mod.fxn = map( data, ~ lmer(aval ~ bl + gaa100 + gaa100:time. + (1 + time.|sjid) , data = . , control = .lme4.ctrl )))
  )

models %>% 
  mutate( fixed.effects = map( mod.fxn, ~ tidy   ( .x, effects = "fixed", conf.int = T ))) %>%
  unnest( fixed.effects ) %>% 
  select(-data, -mod.fxn, -effect, -statistic, -df ) %>% 
  filter( term != '(Intercept)')%>% 
  filter( term != 'bl') %>% 
  # mutate_at(vars(estimate, conf.low, conf.high), ~ 10^.) %>%
  # arrange(group, m) %>% 
  # filter( model == 'interaction only') %>% 
  select( group, paramcd, m, term, estimate, std.error, conf.low, conf.high, p.value) %>%
  .fixmod() %>% 
  filter(term != 'time.') %>% arrange(group) %>% .ct
  print(n=Inf) %>% 
  ggplot()+geom_point()+
  aes(x = term, y = estimate)+
  geom_errorbar(aes(ymin = conf.low, ymax = conf.high))+
  facet_wrap(~group)+
  geom_hline(yintercept = 0, linetype = 2)

# fxn. %>% 
#   ggplot()+geom_point()+
#   aes(x = fxn, y = aval)+
#   facet_wrap(~group)


# DM Figure ------------------------------------------------------------------

# rates <- models. %>%  
#   filter(paramcd != 'FARS.B') %>% 
#   mutate( slp.rates = map( mod.rates, ~ tidy   ( .x, effects = "fixed", conf.int = T))) %>%
#   # select( -c(mod.rates, mod.diffs) ) %>% 
#   unnest( slp.rates ) %>% 
#   mutate( term = gsub('pm.grp','',term)) %>% 
#   mutate( term = gsub(':time.','',term)) %>% 
#   mutate(  estimate.rate =  ( sprintf('%0.1f', estimate) ) ) %>%
#   # mutate( CI.rate = paste0(' (', sprintf('%0.1f', conf.low), ', ', sprintf('%0.1f', conf.high), ')') ) %>% 
#   # select( -c(std.error, statistic, df, conf.low, conf.high, estimate )) %>% 
#   .fixmod() %>% 
#   rename(p.rate = p.value)
# 
# differences <- models. %>%
#   filter(paramcd != 'FARS.B') %>% 
#   mutate( slp.diffs = map( mod.diffs, ~ tidy   ( .x, effects = "fixed", conf.int = T))) %>%
#   select( -c(mod.diffs, mod.rates) ) %>%
#   unnest( slp.diffs ) %>% 
#   mutate( term = gsub('pm.grp','',term)) %>% 
#   mutate( term = gsub(':time.','',term)) %>% 
#   .fixmod()%>%
#   rename(p.diff = p.value)
