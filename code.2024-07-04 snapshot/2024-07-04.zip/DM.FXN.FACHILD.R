
# fxn <- readRDS('DATA derived/fxn.rds') %>% 
#   mutate(pms = factor(ifelse(pm == 0, 0, 1)))

# .mycol <- scale_color_brewer(palette = 'Set1')
# .mycol <- scale_color_manual(values = c(RColorBrewer::brewer.pal(3, 'Set1'), 'darkgrey'))

fxn.child <- .rt('DATA/fxn.txt') %>%
  # filter(grepl('C', sjid)) %>%
  # select(status, pm) %>% table
  select    (sjid, status, mature, isoform.e, total) %>% 
  droplevels()

fxn.child %<>%
  group_by(sjid) %>% arrange(sjid) %>%
  # filter(n()>1) %>%
  group_by(sjid, status) %>%
  summarize_at(vars(mature, isoform.e, total), ~mean(., na.rm = TRUE))

fxn.child %<>% 
  select(-total) %>% 
  gather(type, value, mature, isoform.e) %>% 
  mutate(value = log10(value)) %>% 
  select(status, sjid, type, value)

fxn.child %<>% 
  mutate(origin = 'blood' ) %>% 
  left_join( .dd('demo') ) %>%
  mutate(study = 'FACHILD') %>% 
  # filter(status == 'point mut.') %>% 
  mutate(status =  ifelse( status == 'point mut.', 'patient', status)) %>%
  mutate(status =  ifelse( status == 'homozygous', 'patient', status)) %>%
  mutate ( fxn.unit = 'ng' ) %>%
  rename ( fxn      = value ) %>% 
  select ( study, origin, site, sjid, status, fxn.unit, everything())

fxn.child %>% 
  group_by(origin, status, type) %>%
  summarise( n = n(), s = length(unique(sjid)))
